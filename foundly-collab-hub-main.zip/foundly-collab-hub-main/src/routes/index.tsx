import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Rocket,
  Users,
  Sparkles,
  Briefcase,
  TrendingUp,
  MessageSquare,
  ArrowRight,
  Check,
} from "lucide-react";
import { Logo } from "@/components/logo";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { PERSONAS } from "@/lib/constants";
import heroImage from "@/assets/hero-network.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Foundly — Find Co-Founders. Build Startups. Raise Faster." },
      {
        name: "description",
        content:
          "Foundly is the startup ecosystem where founders, developers, designers, marketers, mentors and investors meet, match and build together with AI-powered co-founder matching.",
      },
      { property: "og:title", content: "Foundly — Find Co-Founders. Build Startups. Raise Faster." },
      {
        property: "og:description",
        content: "Meet your co-founder. Build your team. Raise faster. Join Foundly today.",
      },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { icon: Users, title: "AI Co-Founder Matching", desc: "Swipe and match with the right people by skills, interests, industry and location." },
  { icon: Rocket, title: "Startup Profiles", desc: "Showcase your problem, solution, traction and team to the world." },
  { icon: Briefcase, title: "Team Recruitment", desc: "Post equity, internship and freelance roles. Apply with one profile." },
  { icon: TrendingUp, title: "Investor Hub", desc: "Get discovered by investors and browse the most promising startups." },
  { icon: Sparkles, title: "AI Startup Assistant", desc: "Validate ideas, generate business models and craft your pitch." },
  { icon: MessageSquare, title: "Real-time Messaging", desc: "Connect, chat and move fast with people who get it." },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Logo />
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button variant="ghost" asChild className="hidden sm:inline-flex">
              <Link to="/auth">Sign in</Link>
            </Button>
            <Button variant="hero" asChild>
              <Link to="/auth">Get started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-hero">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs font-medium text-muted-foreground">
              <Sparkles className="size-3.5 text-primary" /> AI-powered startup matching
            </span>
            <h1 className="mt-5 font-display text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
              Find Co-Founders.
              <br />
              Build Startups.
              <br />
              <span className="text-gradient">Raise Faster.</span>
            </h1>
            <p className="mt-5 max-w-md text-lg text-muted-foreground">
              The networking platform where founders, builders, mentors and investors meet, match
              and build the next generation of startups.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button variant="hero" size="xl" asChild>
                <Link to="/auth">
                  Join Foundly <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button variant="outline" size="xl" asChild>
                <Link to="/auth">Explore startups</Link>
              </Button>
            </div>
            <div className="mt-8 flex flex-wrap gap-6 text-sm text-muted-foreground">
              {["Free to join", "No credit card", "Built for founders"].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <Check className="size-4 text-primary" /> {t}
                </span>
              ))}
            </div>
          </div>

          <div className="relative animate-fade-in">
            <div className="absolute -inset-6 rounded-[2rem] bg-gradient-brand opacity-20 blur-3xl" />
            <img
              src={heroImage}
              alt="A glowing network of connected startup founders and builders"
              className="relative w-full rounded-3xl border border-border/60 shadow-lg"
              loading="eager"
            />
          </div>
        </div>
      </section>

      {/* Personas */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight">Built for the whole ecosystem</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Whoever you are, there's a place for you on Foundly.
          </p>
        </div>
        <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
          {PERSONAS.map((p) => (
            <div
              key={p.value}
              className="flex flex-col items-center gap-2 rounded-xl border border-border/60 bg-card p-4 text-center transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
            >
              <div className="grid size-10 place-items-center rounded-lg bg-gradient-brand-soft text-primary">
                <p.icon className="size-5" />
              </div>
              <span className="text-sm font-semibold">{p.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="bg-muted/30 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="text-center">
            <h2 className="font-display text-3xl font-bold tracking-tight">Everything you need to build</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
              From your first co-founder to your first raise.
            </p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="group rounded-2xl border border-border/60 bg-card p-6 transition-all hover:-translate-y-1 hover:shadow-md"
              >
                <div className="grid size-11 place-items-center rounded-xl bg-gradient-brand text-primary-foreground shadow-glow transition-transform group-hover:scale-105">
                  <f.icon className="size-5" />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-brand p-10 text-center text-primary-foreground sm:p-16">
          <div className="absolute inset-0 bg-hero opacity-60" />
          <div className="relative">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Your co-founder is on Foundly.</h2>
            <p className="mx-auto mt-3 max-w-lg text-primary-foreground/85">
              Join the community building the future. It only takes a minute.
            </p>
            <Button
              size="xl"
              variant="secondary"
              className="mt-8 bg-background text-foreground hover:bg-background/90"
              asChild
            >
              <Link to="/auth">
                Get started free <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
          <Logo />
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Foundly. Find Co-Founders. Build Startups. Raise Faster.
          </p>
        </div>
      </footer>
    </div>
  );
}
