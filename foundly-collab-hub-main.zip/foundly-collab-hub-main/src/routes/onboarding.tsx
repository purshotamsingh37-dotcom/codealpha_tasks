import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Logo } from "@/components/logo";
import { ThemeToggle } from "@/components/theme-toggle";
import { TagInput } from "@/components/tag-input";
import { AvatarUploader } from "@/components/avatar-uploader";
import { FullScreenLoader } from "@/components/full-screen-loader";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { PERSONAS, SKILL_SUGGESTIONS, INDUSTRIES, type Persona } from "@/lib/constants";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/onboarding")({
  ssr: false,
  head: () => ({ meta: [{ title: "Set up your profile — Foundly" }] }),
  component: Onboarding,
});

function Onboarding() {
  const { user, profile, loading, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);

  const [persona, setPersona] = useState<Persona | null>(null);
  const [fullName, setFullName] = useState("");
  const [headline, setHeadline] = useState("");
  const [bio, setBio] = useState("");
  const [location, setLocation] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [skills, setSkills] = useState<string[]>([]);
  const [interests, setInterests] = useState<string[]>([]);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      navigate({ to: "/auth", replace: true });
      return;
    }
    if (profile?.onboarded) {
      navigate({ to: "/dashboard", replace: true });
      return;
    }
    if (profile) {
      setFullName(profile.full_name ?? "");
      setAvatarUrl(profile.avatar_url ?? null);
    }
  }, [loading, user, profile, navigate]);

  if (loading || !user || profile?.onboarded) return <FullScreenLoader />;

  const steps = ["Your role", "About you", "Skills & interests"];

  const canNext =
    (step === 0 && !!persona) ||
    (step === 1 && fullName.trim().length >= 2) ||
    step === 2;

  const handleFinish = async () => {
    if (!persona) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          persona,
          full_name: fullName.trim(),
          headline: headline.trim() || null,
          bio: bio.trim() || null,
          location: location.trim() || null,
          avatar_url: avatarUrl,
          skills,
          interests,
          onboarded: true,
        })
        .eq("id", user.id);
      if (error) throw error;
      await refreshProfile();
      toast.success("You're all set! Welcome to Foundly 🚀");
      navigate({ to: "/dashboard", replace: true });
    } catch {
      toast.error("Couldn't save your profile. Try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background bg-hero">
      <header className="flex items-center justify-between px-6 py-5">
        <Logo />
        <ThemeToggle />
      </header>

      <div className="mx-auto w-full max-w-2xl px-4 pb-16 pt-6">
        {/* Stepper */}
        <div className="mb-8 flex items-center gap-2">
          {steps.map((label, i) => (
            <div key={label} className="flex flex-1 items-center gap-2">
              <div
                className={cn(
                  "grid size-8 shrink-0 place-items-center rounded-full border text-sm font-semibold transition-colors",
                  i < step && "border-primary bg-primary text-primary-foreground",
                  i === step && "border-primary bg-gradient-brand text-primary-foreground",
                  i > step && "border-border text-muted-foreground",
                )}
              >
                {i < step ? <Check className="size-4" /> : i + 1}
              </div>
              {i < steps.length - 1 && (
                <div className={cn("h-0.5 flex-1 rounded", i < step ? "bg-primary" : "bg-border")} />
              )}
            </div>
          ))}
        </div>

        <div className="rounded-2xl border border-border/60 bg-card p-6 shadow-md sm:p-8">
          <div key={step} className="animate-fade-up">
            <h1 className="font-display text-2xl font-bold">{steps[step]}</h1>

            {step === 0 && (
              <>
                <p className="mt-1 text-sm text-muted-foreground">
                  How do you want to show up on Foundly?
                </p>
                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {PERSONAS.map((p) => (
                    <button
                      key={p.value}
                      type="button"
                      onClick={() => setPersona(p.value)}
                      className={cn(
                        "flex flex-col items-start gap-2 rounded-xl border p-4 text-left transition-all",
                        persona === p.value
                          ? "border-primary bg-gradient-brand-soft shadow-glow"
                          : "border-border hover:border-primary/40 hover:bg-accent",
                      )}
                    >
                      <p.icon className={cn("size-5", persona === p.value && "text-primary")} />
                      <span className="text-sm font-semibold">{p.label}</span>
                      <span className="text-xs text-muted-foreground">{p.description}</span>
                    </button>
                  ))}
                </div>
              </>
            )}

            {step === 1 && (
              <div className="mt-6 space-y-5">
                <AvatarUploader value={avatarUrl} name={fullName} onChange={setAvatarUrl} />
                <div className="space-y-1.5">
                  <Label htmlFor="name">Full name</Label>
                  <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Ada Lovelace" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="headline">Headline</Label>
                  <Input
                    id="headline"
                    value={headline}
                    onChange={(e) => setHeadline(e.target.value)}
                    placeholder="Technical founder building AI tools"
                    maxLength={120}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="San Francisco, CA" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="bio">Short bio</Label>
                  <Textarea
                    id="bio"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Tell others what you're building and what you're looking for…"
                    rows={4}
                    maxLength={600}
                  />
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="mt-6 space-y-6">
                <div className="space-y-2">
                  <Label>Your skills</Label>
                  <TagInput value={skills} onChange={setSkills} suggestions={SKILL_SUGGESTIONS} placeholder="Add a skill" />
                </div>
                <div className="space-y-2">
                  <Label>Startup interests</Label>
                  <TagInput value={interests} onChange={setInterests} suggestions={INDUSTRIES} placeholder="Add an industry" />
                </div>
              </div>
            )}
          </div>

          <div className="mt-8 flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0}
            >
              <ArrowLeft className="size-4" /> Back
            </Button>
            {step < steps.length - 1 ? (
              <Button variant="hero" onClick={() => setStep((s) => s + 1)} disabled={!canNext}>
                Continue <ArrowRight className="size-4" />
              </Button>
            ) : (
              <Button variant="hero" onClick={handleFinish} disabled={saving}>
                {saving ? "Saving…" : "Finish setup"} <Check className="size-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
