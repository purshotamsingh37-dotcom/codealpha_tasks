import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Save } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TagInput } from "@/components/tag-input";
import { AvatarUploader } from "@/components/avatar-uploader";
import { FullScreenLoader } from "@/components/full-screen-loader";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { PERSONAS, SKILL_SUGGESTIONS, INDUSTRIES, type Persona } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Edit profile — Foundly" }] }),
  component: Settings,
});

function Settings() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState(() => ({
    full_name: profile?.full_name ?? "",
    persona: (profile?.persona ?? "founder") as Persona,
    headline: profile?.headline ?? "",
    bio: profile?.bio ?? "",
    location: profile?.location ?? "",
    avatar_url: profile?.avatar_url ?? null,
    skills: profile?.skills ?? [],
    interests: profile?.interests ?? [],
    experience: profile?.experience ?? "",
    education: profile?.education ?? "",
    linkedin_url: profile?.linkedin_url ?? "",
    github_url: profile?.github_url ?? "",
    portfolio_url: profile?.portfolio_url ?? "",
  }));

  if (!profile || !user) return <FullScreenLoader />;

  const set = <K extends keyof typeof form>(key: K, val: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [key]: val }));

  const handleSave = async () => {
    if (form.full_name.trim().length < 2) {
      toast.error("Please enter your name");
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: form.full_name.trim(),
          persona: form.persona,
          headline: form.headline.trim() || null,
          bio: form.bio.trim() || null,
          location: form.location.trim() || null,
          avatar_url: form.avatar_url,
          skills: form.skills,
          interests: form.interests,
          experience: form.experience.trim() || null,
          education: form.education.trim() || null,
          linkedin_url: form.linkedin_url.trim() || null,
          github_url: form.github_url.trim() || null,
          portfolio_url: form.portfolio_url.trim() || null,
        })
        .eq("id", user.id);
      if (error) throw error;
      await refreshProfile();
      toast.success("Profile saved");
      navigate({ to: "/me" });
    } catch {
      toast.error("Couldn't save. Try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Edit profile" description="Keep your profile sharp to get the best matches." />

      <div className="space-y-6">
        <Card>
          <AvatarUploader
            value={form.avatar_url}
            name={form.full_name}
            onChange={(ref) => set("avatar_url", ref)}
          />
        </Card>

        <Card>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Full name">
              <Input value={form.full_name} onChange={(e) => set("full_name", e.target.value)} />
            </Field>
            <Field label="I am a…">
              <Select value={form.persona} onValueChange={(v) => set("persona", v as Persona)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PERSONAS.map((p) => (
                    <SelectItem key={p.value} value={p.value}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="Headline" className="mt-5">
            <Input
              value={form.headline}
              onChange={(e) => set("headline", e.target.value)}
              placeholder="Technical founder building AI tools"
              maxLength={120}
            />
          </Field>
          <Field label="Location" className="mt-5">
            <Input
              value={form.location}
              onChange={(e) => set("location", e.target.value)}
              placeholder="San Francisco, CA"
            />
          </Field>
          <Field label="Bio" className="mt-5">
            <Textarea
              value={form.bio}
              onChange={(e) => set("bio", e.target.value)}
              rows={4}
              maxLength={600}
              placeholder="Tell others what you're building and what you're looking for…"
            />
          </Field>
        </Card>

        <Card>
          <Field label="Skills">
            <TagInput value={form.skills} onChange={(v) => set("skills", v)} suggestions={SKILL_SUGGESTIONS} />
          </Field>
          <Field label="Startup interests" className="mt-5">
            <TagInput value={form.interests} onChange={(v) => set("interests", v)} suggestions={INDUSTRIES} />
          </Field>
        </Card>

        <Card>
          <Field label="Experience">
            <Textarea
              value={form.experience}
              onChange={(e) => set("experience", e.target.value)}
              rows={3}
              placeholder="Ex-Stripe engineer, founded a fintech startup…"
            />
          </Field>
          <Field label="Education" className="mt-5">
            <Textarea
              value={form.education}
              onChange={(e) => set("education", e.target.value)}
              rows={2}
              placeholder="BSc Computer Science, MIT"
            />
          </Field>
        </Card>

        <Card>
          <div className="grid gap-5">
            <Field label="LinkedIn URL">
              <Input value={form.linkedin_url} onChange={(e) => set("linkedin_url", e.target.value)} placeholder="https://linkedin.com/in/…" />
            </Field>
            <Field label="GitHub URL">
              <Input value={form.github_url} onChange={(e) => set("github_url", e.target.value)} placeholder="https://github.com/…" />
            </Field>
            <Field label="Portfolio / Website">
              <Input value={form.portfolio_url} onChange={(e) => set("portfolio_url", e.target.value)} placeholder="https://…" />
            </Field>
          </div>
        </Card>

        <div className="flex justify-end gap-3">
          <Button variant="ghost" onClick={() => navigate({ to: "/me" })}>
            Cancel
          </Button>
          <Button variant="hero" onClick={handleSave} disabled={saving}>
            <Save className="size-4" /> {saving ? "Saving…" : "Save changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">{children}</div>;
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <Label className="mb-1.5 block">{label}</Label>
      {children}
    </div>
  );
}
