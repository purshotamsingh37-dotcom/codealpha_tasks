import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Rocket, Upload, FileText, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { StartupLogo } from "@/components/startup-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { uploadFile } from "@/lib/storage";
import { INDUSTRIES, FUNDING_STAGES } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/startups/new")({
  head: () => ({ meta: [{ title: "Create a startup — Foundly" }] }),
  component: NewStartup,
});

function NewStartup() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const logoRef = useRef<HTMLInputElement>(null);
  const deckRef = useRef<HTMLInputElement>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingDeck, setUploadingDeck] = useState(false);
  const [deckName, setDeckName] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    name: "",
    tagline: "",
    logo_url: null as string | null,
    industry: "",
    funding_stage: "",
    problem: "",
    solution: "",
    website: "",
    pitch_deck_url: null as string | null,
  });

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const handleLogo = async (file?: File) => {
    if (!file || !user) return;
    if (file.size > 5 * 1024 * 1024) return toast.error("Logo must be under 5MB");
    setUploadingLogo(true);
    try {
      set("logo_url", await uploadFile("startup-logos", user.id, file));
    } catch {
      toast.error("Logo upload failed");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleDeck = async (file?: File) => {
    if (!file || !user) return;
    if (file.size > 20 * 1024 * 1024) return toast.error("Deck must be under 20MB");
    setUploadingDeck(true);
    try {
      set("pitch_deck_url", await uploadFile("pitch-decks", user.id, file));
      setDeckName(file.name);
      toast.success("Pitch deck uploaded");
    } catch {
      toast.error("Deck upload failed");
    } finally {
      setUploadingDeck(false);
    }
  };

  const handleCreate = async () => {
    if (form.name.trim().length < 2) return toast.error("Enter a startup name");
    if (!user) return;
    setSaving(true);
    try {
      const { data, error } = await supabase
        .from("startups")
        .insert({
          owner_id: user.id,
          name: form.name.trim(),
          tagline: form.tagline.trim() || null,
          logo_url: form.logo_url,
          industry: form.industry || null,
          funding_stage: form.funding_stage || null,
          problem: form.problem.trim() || null,
          solution: form.solution.trim() || null,
          website: form.website.trim() || null,
          pitch_deck_url: form.pitch_deck_url,
        })
        .select("id")
        .single();
      if (error) throw error;
      toast.success("Startup created 🚀");
      navigate({ to: "/startup/$id", params: { id: data.id } });
    } catch {
      toast.error("Couldn't create startup. Try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Create a startup" description="Share your vision and start building your team." />

      <div className="space-y-6">
        <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">
          <div className="flex items-center gap-4">
            <button type="button" onClick={() => logoRef.current?.click()} className="relative">
              <StartupLogo src={form.logo_url} name={form.name} className="size-20" />
              <span className="absolute inset-0 grid place-items-center rounded-xl bg-foreground/40 opacity-0 transition-opacity hover:opacity-100">
                {uploadingLogo ? (
                  <Loader2 className="size-5 animate-spin text-background" />
                ) : (
                  <Upload className="size-5 text-background" />
                )}
              </span>
            </button>
            <div className="flex-1">
              <Label className="mb-1.5 block">Startup name</Label>
              <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Acme AI" />
            </div>
          </div>
          <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleLogo(e.target.files?.[0])} />

          <div className="mt-5">
            <Label className="mb-1.5 block">Tagline</Label>
            <Input
              value={form.tagline}
              onChange={(e) => set("tagline", e.target.value)}
              placeholder="The AI co-pilot for sales teams"
              maxLength={140}
            />
          </div>
        </div>

        <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <Label className="mb-1.5 block">Industry</Label>
              <Select value={form.industry} onValueChange={(v) => set("industry", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent>
                  {INDUSTRIES.map((i) => (
                    <SelectItem key={i} value={i}>
                      {i}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block">Funding stage</Label>
              <Select value={form.funding_stage} onValueChange={(v) => set("funding_stage", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent>
                  {FUNDING_STAGES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-5">
            <Label className="mb-1.5 block">Website</Label>
            <Input value={form.website} onChange={(e) => set("website", e.target.value)} placeholder="https://…" />
          </div>
        </div>

        <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">
          <div>
            <Label className="mb-1.5 block">Problem</Label>
            <Textarea
              value={form.problem}
              onChange={(e) => set("problem", e.target.value)}
              rows={3}
              placeholder="What problem are you solving?"
            />
          </div>
          <div className="mt-5">
            <Label className="mb-1.5 block">Solution</Label>
            <Textarea
              value={form.solution}
              onChange={(e) => set("solution", e.target.value)}
              rows={3}
              placeholder="How do you solve it?"
            />
          </div>
        </div>

        <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">
          <Label className="mb-1.5 block">Pitch deck (private)</Label>
          <button
            type="button"
            onClick={() => deckRef.current?.click()}
            className="flex w-full items-center gap-3 rounded-lg border border-dashed border-border p-4 text-left transition-colors hover:border-primary/40"
          >
            <div className="grid size-10 place-items-center rounded-lg bg-gradient-brand-soft text-primary">
              {uploadingDeck ? <Loader2 className="size-5 animate-spin" /> : <FileText className="size-5" />}
            </div>
            <div className="text-sm">
              <div className="font-medium">{deckName ?? "Upload pitch deck"}</div>
              <div className="text-xs text-muted-foreground">PDF up to 20MB — only you can see this</div>
            </div>
          </button>
          <input
            ref={deckRef}
            type="file"
            accept=".pdf,application/pdf"
            className="hidden"
            onChange={(e) => handleDeck(e.target.files?.[0])}
          />
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="ghost" onClick={() => navigate({ to: "/startups" })}>
            Cancel
          </Button>
          <Button variant="hero" onClick={handleCreate} disabled={saving}>
            <Rocket className="size-4" /> {saving ? "Creating…" : "Create startup"}
          </Button>
        </div>
      </div>
    </div>
  );
}
