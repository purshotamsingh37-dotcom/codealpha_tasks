import { createFileRoute } from "@tanstack/react-router";
import { ProfileDetail } from "@/components/profile-detail";
import { FullScreenLoader } from "@/components/full-screen-loader";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/me")({
  head: () => ({ meta: [{ title: "My profile — Foundly" }] }),
  component: MyProfile,
});

function MyProfile() {
  const { profile } = useAuth();
  if (!profile) return <FullScreenLoader />;
  return <ProfileDetail profile={profile} isOwn />;
}
