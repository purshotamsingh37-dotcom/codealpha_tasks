import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Users,
  Rocket,
  Sparkles,
  TrendingUp,
  ArrowRight,
  Bell,
  Plus,
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { ProfileCard } from "@/components/profile-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { PERSONA_MAP, type Persona } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const { user, profile } = useAuth();

  const { data: suggested, isLoading: loadingPeople } = useQuery({
    queryKey: ["suggested-people", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, headline, avatar_url, location, persona, skills")
        .eq("onboarded", true)
        .neq("id", user!.id)
        .limit(4);
      return data ?? [];
    },
    enabled: !!user,
  });

  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats", user?.id],
    queryFn: async () => {
      const [{ count: members }, { count: startups }, { count: mine }] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("onboarded", true),
        supabase.from("startups").select("id", { count: "exact", head: true }),
        supabase.from("startups").select("id", { count: "exact", head: true }).eq("owner_id", user!.id),
      ]);
      return { members: members ?? 0, startups: startups ?? 0, mine: mine ?? 0 };
    },
    enabled: !!user,
  });

  const firstName = (profile?.full_name || "there").split(" ")[0];
  const meta = profile?.persona ? PERSONA_MAP[profile.persona as Persona] : null;

  const statCards = [
    { label: "Members", value: stats?.members ?? "—", icon: Users, to: "/discover" as const },
    { label: "Startups", value: stats?.startups ?? "—", icon: Rocket, to: "/startups" as const },
    { label: "Your startups", value: stats?.mine ?? "—", icon: TrendingUp, to: "/startups" as const },
  ];

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${firstName} 👋`}
        description={meta ? `Your dashboard as a ${meta.label.toLowerCase()}.` : "Here's what's happening."}
        action={
          <Button variant="hero" asChild>
            <Link to="/startups/new">
              <Plus className="size-4" /> New startup
            </Link>
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {statCards.map((s) => (
          <Link
            key={s.label}
            to={s.to}
            className="flex items-center gap-4 rounded-2xl border border-border/60 bg-card p-5 transition-all hover:border-primary/40 hover:shadow-md"
          >
            <div className="grid size-11 place-items-center rounded-xl bg-gradient-brand-soft text-primary">
              <s.icon className="size-5" />
            </div>
            <div>
              <div className="font-display text-2xl font-bold">{s.value}</div>
              <div className="text-sm text-muted-foreground">{s.label}</div>
            </div>
          </Link>
        ))}
      </div>

      {/* AI banner */}
      <div className="mt-6 overflow-hidden rounded-2xl border border-border/60 bg-gradient-brand p-6 text-primary-foreground">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Sparkles className="size-6" />
            <div>
              <h3 className="font-display text-lg font-bold">AI Startup Assistant</h3>
              <p className="text-sm text-primary-foreground/85">
                Validate ideas, generate business models and find your perfect co-founder.
              </p>
            </div>
          </div>
          <Button variant="secondary" className="bg-white/15 text-primary-foreground hover:bg-white/25" disabled>
            Coming soon
          </Button>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* Suggested people */}
        <div className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">People you should meet</h2>
            <Link to="/discover" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
              See all <ArrowRight className="size-3.5" />
            </Link>
          </div>
          {loadingPeople ? (
            <div className="grid gap-4 sm:grid-cols-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-40 rounded-2xl" />
              ))}
            </div>
          ) : suggested && suggested.length > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2">
              {suggested.map((p) => (
                <ProfileCard key={p.id} profile={p} />
              ))}
            </div>
          ) : (
            <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
              No other members yet — invite your network to Foundly!
            </p>
          )}
        </div>

        {/* Opportunity alerts */}
        <div>
          <h2 className="mb-4 font-display text-lg font-semibold">Opportunity alerts</h2>
          <div className="space-y-3">
            {[
              { icon: Users, text: "Complete your profile to get better matches" },
              { icon: Rocket, text: "Create a startup to start recruiting" },
              { icon: Bell, text: "Co-founder matching launches soon" },
            ].map((a, i) => (
              <div
                key={i}
                className="flex items-start gap-3 rounded-xl border border-border/60 bg-card p-4"
              >
                <div className="grid size-8 shrink-0 place-items-center rounded-lg bg-gradient-brand-soft text-primary">
                  <a.icon className="size-4" />
                </div>
                <p className="text-sm text-muted-foreground">{a.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
