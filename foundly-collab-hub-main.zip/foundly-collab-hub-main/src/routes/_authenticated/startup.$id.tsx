import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Globe, Trash2, FileText, ExternalLink } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { StartupLogo } from "@/components/startup-logo";
import { UserAvatar } from "@/components/user-avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { resolveSignedUrl } from "@/lib/storage";

export const Route = createFileRoute("/_authenticated/startup/$id")({
  component: StartupDetail,
});

function StartupDetail() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [deleting, setDeleting] = useState(false);

  const { data: startup, isLoading } = useQuery({
    queryKey: ["startup", id],
    queryFn: async () => {
      const { data } = await supabase.from("startups").select("*").eq("id", id).maybeSingle();
      return data;
    },
  });

  const { data: owner } = useQuery({
    queryKey: ["startup-owner", startup?.owner_id],
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, headline, avatar_url")
        .eq("id", startup!.owner_id)
        .maybeSingle();
      return data;
    },
    enabled: !!startup?.owner_id,
  });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl space-y-4">
        <Skeleton className="h-32 rounded-2xl" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!startup) {
    return (
      <div className="mx-auto max-w-md py-20 text-center">
        <h1 className="font-display text-xl font-semibold">Startup not found</h1>
        <Button variant="outline" className="mt-6" asChild>
          <Link to="/startups">
            <ArrowLeft className="size-4" /> Back to startups
          </Link>
        </Button>
      </div>
    );
  }

  const isOwner = startup.owner_id === user?.id;

  const openDeck = async () => {
    const url = await resolveSignedUrl(startup.pitch_deck_url);
    if (url) window.open(url, "_blank");
    else toast.error("Couldn't open the pitch deck");
  };

  const handleDelete = async () => {
    setDeleting(true);
    const { error } = await supabase.from("startups").delete().eq("id", startup.id);
    if (error) {
      toast.error("Couldn't delete");
      setDeleting(false);
    } else {
      toast.success("Startup deleted");
      navigate({ to: "/startups" });
    }
  };

  return (
    <div className="mx-auto max-w-3xl">
      <Button variant="ghost" size="sm" className="mb-4" asChild>
        <Link to="/startups">
          <ArrowLeft className="size-4" /> Startups
        </Link>
      </Button>

      <div className="rounded-2xl border border-border/60 bg-card p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <StartupLogo src={startup.logo_url} name={startup.name} className="size-16" />
            <div>
              <h1 className="font-display text-2xl font-bold">{startup.name}</h1>
              {startup.tagline && <p className="mt-0.5 text-muted-foreground">{startup.tagline}</p>}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                {startup.industry && (
                  <Badge variant="secondary" className="bg-gradient-brand-soft">
                    {startup.industry}
                  </Badge>
                )}
                {startup.funding_stage && <Badge variant="outline">{startup.funding_stage}</Badge>}
              </div>
            </div>
          </div>
          {isOwner && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">
                  <Trash2 className="size-4" /> Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this startup?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This permanently removes {startup.name}. This action can't be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} disabled={deleting}>
                    {deleting ? "Deleting…" : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        <div className="mt-4 flex flex-wrap gap-3">
          {startup.website && (
            <a
              href={startup.website}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm transition-colors hover:border-primary/40 hover:text-primary"
            >
              <Globe className="size-4" /> Website <ExternalLink className="size-3" />
            </a>
          )}
          {isOwner && startup.pitch_deck_url && (
            <button
              onClick={openDeck}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm transition-colors hover:border-primary/40 hover:text-primary"
            >
              <FileText className="size-4" /> View pitch deck
            </button>
          )}
        </div>
      </div>

      <div className="mt-6 grid gap-6">
        {startup.problem && (
          <Section title="Problem">
            <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{startup.problem}</p>
          </Section>
        )}
        {startup.solution && (
          <Section title="Solution">
            <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{startup.solution}</p>
          </Section>
        )}

        {owner && (
          <Section title="Founder">
            <Link
              to="/profile/$id"
              params={{ id: owner.id }}
              className="flex items-center gap-3 rounded-xl border border-border/60 p-3 transition-colors hover:border-primary/40"
            >
              <UserAvatar src={owner.avatar_url} name={owner.full_name} className="size-11" />
              <div>
                <div className="font-medium">{owner.full_name || "Founder"}</div>
                <div className="text-sm text-muted-foreground">{owner.headline}</div>
              </div>
            </Link>
          </Section>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">
      <h2 className="mb-3 font-display text-base font-semibold">{title}</h2>
      {children}
    </div>
  );
}
