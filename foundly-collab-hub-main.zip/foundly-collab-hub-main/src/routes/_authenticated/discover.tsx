import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { ProfileCard } from "@/components/profile-card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { PERSONAS, type Persona } from "@/lib/constants";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/discover")({
  head: () => ({ meta: [{ title: "Discover people — Foundly" }] }),
  component: Discover,
});

function Discover() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [persona, setPersona] = useState<Persona | "all">("all");

  const { data, isLoading } = useQuery({
    queryKey: ["discover-people", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, headline, avatar_url, location, persona, skills")
        .eq("onboarded", true)
        .neq("id", user!.id)
        .order("updated_at", { ascending: false })
        .limit(60);
      return data ?? [];
    },
    enabled: !!user,
  });

  const filtered = (data ?? []).filter((p) => {
    if (persona !== "all" && p.persona !== persona) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      p.full_name?.toLowerCase().includes(q) ||
      p.headline?.toLowerCase().includes(q) ||
      p.location?.toLowerCase().includes(q) ||
      p.skills?.some((s) => s.toLowerCase().includes(q))
    );
  });

  return (
    <div>
      <PageHeader
        title="Discover people"
        description="Find co-founders, teammates, mentors and investors."
      />

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, skill, headline or location…"
          className="pl-9"
        />
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        <FilterChip active={persona === "all"} onClick={() => setPersona("all")}>
          All
        </FilterChip>
        {PERSONAS.map((p) => (
          <FilterChip key={p.value} active={persona === p.value} onClick={() => setPersona(p.value)}>
            <p.icon className="size-3.5" /> {p.label}
          </FilterChip>
        ))}
      </div>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-44 rounded-2xl" />
          ))}
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <ProfileCard key={p.id} profile={p} />
          ))}
        </div>
      ) : (
        <p className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">
          No members match your filters yet.
        </p>
      )}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
        active
          ? "border-primary bg-gradient-brand-soft text-foreground"
          : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}
