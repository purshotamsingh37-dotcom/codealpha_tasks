import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Search, Globe } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { StartupLogo } from "@/components/startup-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { INDUSTRIES } from "@/lib/constants";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/startups/")({
  head: () => ({ meta: [{ title: "Startups — Foundly" }] }),
  component: Startups,
});

function Startups() {
  const [search, setSearch] = useState("");
  const [industry, setIndustry] = useState<string>("all");

  const { data, isLoading } = useQuery({
    queryKey: ["startups"],
    queryFn: async () => {
      const { data } = await supabase
        .from("startups")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(60);
      return data ?? [];
    },
  });

  const filtered = (data ?? []).filter((s) => {
    if (industry !== "all" && s.industry !== industry) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      s.name.toLowerCase().includes(q) ||
      s.tagline?.toLowerCase().includes(q) ||
      s.problem?.toLowerCase().includes(q)
    );
  });

  const industryOptions = ["all", ...INDUSTRIES.filter((i) => data?.some((s) => s.industry === i))];

  return (
    <div>
      <PageHeader
        title="Startups"
        description="Browse, discover and follow startups building the future."
        action={
          <Button variant="hero" asChild>
            <Link to="/startups/new">
              <Plus className="size-4" /> Create startup
            </Link>
          </Button>
        }
      />

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search startups…"
          className="pl-9"
        />
      </div>

      {industryOptions.length > 1 && (
        <div className="mb-6 flex flex-wrap gap-2">
          {industryOptions.map((opt) => (
            <button
              key={opt}
              onClick={() => setIndustry(opt)}
              className={cn(
                "rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
                industry === opt
                  ? "border-primary bg-gradient-brand-soft text-foreground"
                  : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
              )}
            >
              {opt === "all" ? "All industries" : opt}
            </button>
          ))}
        </div>
      )}

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-2xl" />
          ))}
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((s) => (
            <Link
              key={s.id}
              to="/startup/$id"
              params={{ id: s.id }}
              className="group flex flex-col rounded-2xl border border-border/60 bg-card p-5 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
            >
              <div className="flex items-start gap-3">
                <StartupLogo src={s.logo_url} name={s.name} />
                <div className="min-w-0 flex-1">
                  <h3 className="truncate font-semibold group-hover:text-primary">{s.name}</h3>
                  <p className="line-clamp-2 text-sm text-muted-foreground">
                    {s.tagline || s.problem || "A new startup on Foundly"}
                  </p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                {s.industry && (
                  <Badge variant="secondary" className="bg-gradient-brand-soft">
                    {s.industry}
                  </Badge>
                )}
                {s.funding_stage && <Badge variant="outline">{s.funding_stage}</Badge>}
                {s.website && <Globe className="size-3.5 text-muted-foreground" />}
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <p className="text-muted-foreground">No startups yet.</p>
          <Button variant="hero" className="mt-4" asChild>
            <Link to="/startups/new">
              <Plus className="size-4" /> Be the first to create one
            </Link>
          </Button>
        </div>
      )}
    </div>
  );
}
