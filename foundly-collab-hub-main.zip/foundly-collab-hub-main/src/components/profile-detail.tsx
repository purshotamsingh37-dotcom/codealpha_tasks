import { Link } from "@tanstack/react-router";
import {
  MapPin,
  Linkedin,
  Github,
  Globe,
  Pencil,
  Briefcase,
  GraduationCap,
} from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";
import { UserAvatar } from "@/components/user-avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PERSONA_MAP, type Persona } from "@/lib/constants";

export function ProfileDetail({
  profile,
  isOwn,
}: {
  profile: Tables<"profiles">;
  isOwn: boolean;
}) {
  const meta = profile.persona ? PERSONA_MAP[profile.persona as Persona] : null;
  const links = [
    { url: profile.linkedin_url, icon: Linkedin, label: "LinkedIn" },
    { url: profile.github_url, icon: Github, label: "GitHub" },
    { url: profile.portfolio_url, icon: Globe, label: "Portfolio" },
  ].filter((l) => l.url);

  return (
    <div className="mx-auto max-w-3xl">
      {/* Banner */}
      <div className="h-36 rounded-2xl bg-gradient-brand bg-hero sm:h-44" />

      <div className="-mt-14 px-4 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <UserAvatar
            src={profile.avatar_url}
            name={profile.full_name}
            className="size-28 border-4 border-background text-2xl shadow-md"
          />
          {isOwn && (
            <Button variant="outline" asChild>
              <Link to="/settings">
                <Pencil className="size-4" /> Edit profile
              </Link>
            </Button>
          )}
        </div>

        <div className="mt-4">
          <h1 className="font-display text-2xl font-bold sm:text-3xl">
            {profile.full_name || "Unnamed member"}
          </h1>
          {profile.headline && <p className="mt-1 text-lg text-muted-foreground">{profile.headline}</p>}

          <div className="mt-3 flex flex-wrap items-center gap-3">
            {meta && (
              <Badge variant="secondary" className="gap-1 bg-gradient-brand-soft">
                <meta.icon className="size-3.5" /> {meta.label}
              </Badge>
            )}
            {profile.location && (
              <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
                <MapPin className="size-4" /> {profile.location}
              </span>
            )}
          </div>

          {links.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {links.map((l) => (
                <a
                  key={l.label}
                  href={l.url!}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm transition-colors hover:border-primary/40 hover:text-primary"
                >
                  <l.icon className="size-4" /> {l.label}
                </a>
              ))}
            </div>
          )}
        </div>

        <div className="mt-8 space-y-6">
          {profile.bio && (
            <Section title="About">
              <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                {profile.bio}
              </p>
            </Section>
          )}

          {profile.skills.length > 0 && (
            <Section title="Skills">
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((s) => (
                  <Badge key={s} variant="outline" className="bg-card">
                    {s}
                  </Badge>
                ))}
              </div>
            </Section>
          )}

          {profile.interests.length > 0 && (
            <Section title="Startup interests">
              <div className="flex flex-wrap gap-2">
                {profile.interests.map((s) => (
                  <Badge key={s} variant="secondary" className="bg-gradient-brand-soft">
                    {s}
                  </Badge>
                ))}
              </div>
            </Section>
          )}

          {profile.experience && (
            <Section title="Experience" icon={Briefcase}>
              <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                {profile.experience}
              </p>
            </Section>
          )}

          {profile.education && (
            <Section title="Education" icon={GraduationCap}>
              <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                {profile.education}
              </p>
            </Section>
          )}
        </div>
      </div>
    </div>
  );
}

function Section({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon?: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-5 sm:p-6">
      <h2 className="mb-3 flex items-center gap-2 font-display text-base font-semibold">
        {Icon && <Icon className="size-4 text-primary" />}
        {title}
      </h2>
      {children}
    </div>
  );
}
