import { Logo } from "@/components/logo";

export function FullScreenLoader() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background">
      <div className="animate-pulse-glow">
        <Logo showText={false} />
      </div>
      <div className="h-1 w-32 overflow-hidden rounded-full bg-muted">
        <div className="h-full w-1/2 animate-[shimmer_1.2s_infinite] rounded-full bg-gradient-brand" />
      </div>
    </div>
  );
}
