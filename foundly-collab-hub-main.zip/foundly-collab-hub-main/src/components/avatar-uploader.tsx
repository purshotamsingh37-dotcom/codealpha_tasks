import { useRef, useState } from "react";
import { Camera, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { UserAvatar } from "@/components/user-avatar";
import { uploadFile } from "@/lib/storage";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

export function AvatarUploader({
  value,
  name,
  onChange,
  className,
}: {
  value: string | null;
  name?: string | null;
  onChange: (ref: string) => void;
  className?: string;
}) {
  const { user } = useAuth();
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file?: File) => {
    if (!file || !user) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be under 5MB");
      return;
    }
    setUploading(true);
    try {
      const ref = await uploadFile("avatars", user.id, file);
      onChange(ref);
      toast.success("Photo updated");
    } catch {
      toast.error("Upload failed, please try again");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className={cn("flex items-center gap-4", className)}>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="group relative rounded-full"
      >
        <UserAvatar src={value} name={name} className="size-20 text-lg" />
        <span className="absolute inset-0 grid place-items-center rounded-full bg-foreground/50 opacity-0 transition-opacity group-hover:opacity-100">
          {uploading ? (
            <Loader2 className="size-5 animate-spin text-background" />
          ) : (
            <Camera className="size-5 text-background" />
          )}
        </span>
      </button>
      <div className="text-sm">
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="font-medium text-primary hover:underline"
        >
          {value ? "Change photo" : "Upload photo"}
        </button>
        <p className="text-xs text-muted-foreground">JPG or PNG, up to 5MB</p>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}
