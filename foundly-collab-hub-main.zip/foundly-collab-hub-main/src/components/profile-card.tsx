import { Link } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";
import { UserAvatar } from "@/components/user-avatar";
import { Badge } from "@/components/ui/badge";
import { PERSONA_MAP, type Persona } from "@/lib/constants";

type ProfileRow = Pick<
  Tables<"profiles">,
  "id" | "full_name" | "headline" | "avatar_url" | "location" | "persona" | "skills"
>;

export function ProfileCard({ profile }: { profile: ProfileRow }) {
  const meta = profile.persona ? PERSONA_MAP[profile.persona as Persona] : null;
  return (
    <Link
      to="/profile/$id"
      params={{ id: profile.id }}
      className="group flex flex-col rounded-2xl border border-border/60 bg-card p-5 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
    >
      <div className="flex items-start gap-3">
        <UserAvatar src={profile.avatar_url} name={profile.full_name} className="size-14 text-base" />
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold group-hover:text-primary">
            {profile.full_name || "Unnamed member"}
          </h3>
          <p className="line-clamp-2 text-sm text-muted-foreground">
            {profile.headline || "Foundly member"}
          </p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {meta && (
          <Badge variant="secondary" className="gap-1 bg-gradient-brand-soft">
            <meta.icon className="size-3" /> {meta.label}
          </Badge>
        )}
        {profile.location && (
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="size-3" /> {profile.location}
          </span>
        )}
      </div>

      {profile.skills && profile.skills.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {profile.skills.slice(0, 4).map((s) => (
            <span key={s} className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
              {s}
            </span>
          ))}
          {profile.skills.length > 4 && (
            <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
              +{profile.skills.length - 4}
            </span>
          )}
        </div>
      )}
    </Link>
  );
}
