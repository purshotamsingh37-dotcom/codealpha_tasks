import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useSignedUrl } from "@/hooks/use-signed-url";
import { cn } from "@/lib/utils";

function initials(name?: string | null) {
  if (!name) return "?";
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

export function UserAvatar({
  src,
  name,
  className,
}: {
  src?: string | null;
  name?: string | null;
  className?: string;
}) {
  const url = useSignedUrl(src);
  return (
    <Avatar className={cn("border border-border/60", className)}>
      {url && <AvatarImage src={url} alt={name ?? "User"} className="object-cover" />}
      <AvatarFallback className="bg-gradient-brand-soft font-semibold text-foreground">
        {initials(name)}
      </AvatarFallback>
    </Avatar>
  );
}
