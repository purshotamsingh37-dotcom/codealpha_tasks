import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Logo({
  className,
  showText = true,
  to = "/",
  solid = false,
}: {
  className?: string;
  showText?: boolean;
  to?: string;
  solid?: boolean;
}) {
  return (
    <Link to={to} className={cn("group flex items-center gap-2.5", className)}>
      <span className="relative grid size-9 place-items-center rounded-xl bg-gradient-brand shadow-glow transition-transform group-hover:scale-105">
        <svg viewBox="0 0 24 24" className="size-5 text-primary-foreground" fill="none">
          <path
            d="M12 2.5c3.4 2 5.5 5.6 5.5 9.5 0 1.8-.5 3.2-1.2 4.4L12 14l-4.3 2.4C7 15.2 6.5 13.8 6.5 12c0-3.9 2.1-7.5 5.5-9.5Z"
            fill="currentColor"
          />
          <path d="M9.2 18.2 12 16.6l2.8 1.6-2.8 3.3-2.8-3.3Z" fill="currentColor" opacity="0.7" />
        </svg>
      </span>
      {showText &&
        (solid ? (
          <span className="font-display text-xl font-bold tracking-tight">Foundly</span>
        ) : (
          <span className="font-display text-xl font-bold tracking-tight">
            Found<span className="text-gradient">ly</span>
          </span>
        ))}
    </Link>
  );
}
