import { Rocket } from "lucide-react";
import { useSignedUrl } from "@/hooks/use-signed-url";
import { cn } from "@/lib/utils";

export function StartupLogo({
  src,
  name,
  className,
}: {
  src?: string | null;
  name?: string | null;
  className?: string;
}) {
  const url = useSignedUrl(src);
  return (
    <div
      className={cn(
        "grid size-12 shrink-0 place-items-center overflow-hidden rounded-xl border border-border/60 bg-gradient-brand-soft",
        className,
      )}
    >
      {url ? (
        <img src={url} alt={name ?? "Startup logo"} className="size-full object-cover" />
      ) : (
        <Rocket className="size-1/2 text-primary" />
      )}
    </div>
  );
}
