import { useEffect, useState } from "react";
import { resolveSignedUrl } from "@/lib/storage";

export function useSignedUrl(ref: string | null | undefined) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    if (!ref) {
      setUrl(null);
      return;
    }
    resolveSignedUrl(ref).then((u) => {
      if (active) setUrl(u);
    });
    return () => {
      active = false;
    };
  }, [ref]);

  return url;
}
