import { supabase } from "@/integrations/supabase/client";

type BucketId = "avatars" | "startup-logos" | "pitch-decks";

// In-memory cache so we don't re-sign the same path repeatedly.
const signedCache = new Map<string, { url: string; expires: number }>();

/**
 * Uploads a file to a user-scoped folder (so storage RLS passes) and returns
 * the stored object path (NOT a public URL, buckets are private).
 */
export async function uploadFile(
  bucket: BucketId,
  userId: string,
  file: File,
): Promise<string> {
  const ext = file.name.split(".").pop() ?? "bin";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    upsert: true,
    contentType: file.type || undefined,
  });
  if (error) throw error;
  return `${bucket}/${path}`;
}

/**
 * Resolves a stored "bucket/path" reference into a temporary signed URL.
 * Returns null for empty input.
 */
export async function resolveSignedUrl(
  ref: string | null | undefined,
): Promise<string | null> {
  if (!ref) return null;
  // Already a full URL (e.g. Google avatar) — return as-is.
  if (ref.startsWith("http")) return ref;

  const cached = signedCache.get(ref);
  if (cached && cached.expires > Date.now()) return cached.url;

  const [bucket, ...rest] = ref.split("/");
  const path = rest.join("/");
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(path, 60 * 60);
  if (error || !data) return null;
  signedCache.set(ref, { url: data.signedUrl, expires: Date.now() + 50 * 60 * 1000 });
  return data.signedUrl;
}
