import {
  Rocket,
  Code2,
  Palette,
  Megaphone,
  TrendingUp,
  GraduationCap,
  Lightbulb,
  type LucideIcon,
} from "lucide-react";

export type Persona =
  | "founder"
  | "developer"
  | "designer"
  | "marketer"
  | "investor"
  | "mentor"
  | "student";

export interface PersonaMeta {
  value: Persona;
  label: string;
  description: string;
  icon: LucideIcon;
}

export const PERSONAS: PersonaMeta[] = [
  { value: "founder", label: "Founder", description: "Building or leading a startup", icon: Rocket },
  { value: "developer", label: "Developer", description: "Engineering products & infra", icon: Code2 },
  { value: "designer", label: "Designer", description: "Product, brand & UX design", icon: Palette },
  { value: "marketer", label: "Marketer", description: "Growth, content & demand", icon: Megaphone },
  { value: "investor", label: "Investor", description: "Backing ambitious teams", icon: TrendingUp },
  { value: "mentor", label: "Mentor", description: "Advising & coaching founders", icon: Lightbulb },
  { value: "student", label: "Student", description: "Learning & breaking in", icon: GraduationCap },
];

export const PERSONA_MAP: Record<Persona, PersonaMeta> = PERSONAS.reduce(
  (acc, p) => {
    acc[p.value] = p;
    return acc;
  },
  {} as Record<Persona, PersonaMeta>,
);

export const INDUSTRIES = [
  "AI / ML",
  "SaaS",
  "Fintech",
  "Healthtech",
  "Edtech",
  "E-commerce",
  "Climate",
  "Developer Tools",
  "Consumer",
  "Web3 / Crypto",
  "Marketplace",
  "Hardware",
  "Biotech",
  "Gaming",
  "Productivity",
];

export const FUNDING_STAGES = [
  "Idea",
  "Pre-seed",
  "Seed",
  "Series A",
  "Series B+",
  "Bootstrapped",
  "Profitable",
];

export const SKILL_SUGGESTIONS = [
  "Product",
  "Frontend",
  "Backend",
  "Full-stack",
  "UI/UX",
  "Branding",
  "Growth",
  "Sales",
  "Fundraising",
  "Data Science",
  "Machine Learning",
  "DevOps",
  "Content",
  "Community",
  "Operations",
  "Finance",
];
